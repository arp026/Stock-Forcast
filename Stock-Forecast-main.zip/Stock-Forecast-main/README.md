# Stock-Forecast
Deep Learning Model based project predicting the opening-closing stock prices from past data.
